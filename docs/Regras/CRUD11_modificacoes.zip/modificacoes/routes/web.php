<?php
use App\Http\Controllers\EstudoController;
use App\Http\Controllers\CrudController;

use App\Http\Controllers\ProfileController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
require __DIR__.'/auth.php'; // Tava no final do codigo.

Route::get('/1', function () {
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
    ]);
});

/*
Route::get('/dashboard', function () {
    return Inertia::render('Dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');
  */  
// 💡 Rota pública para onde o usuário será enviado após se cadastrar

Route::get('/em-analise', function () {
    return Inertia::render('Auth/EmAnalise'); // Criaremos essa tela no Vue
})->name('em-analise');

Route::middleware('auth')->group(function () {
    Route::post('/alterar-senha', [CrudController::class, 'alterarSenha'])->name('password.alterar');


    // https://gemini.google.com/share/5370ba57f132
    // localhost:8020/crud/
    Route::prefix('crud')->group(function(){
        
        // URL: localhost:8020/crud
        Route::get('/', [CrudController::class, 'index'])->name('crud.index');
        
        // Novo registro
        Route::post('/', [CrudController::class, 'store'])->name('crud.store');

        // URL: localhost:8020/crud/{id} (Corrigido removendo o 'crud' duplicado)
        Route::put('/{id}', [CrudController::class, 'update'])->name('crud.update');
        
        // URL: localhost:8020/crud/{id}
        Route::delete('/{id}', [CrudController::class, 'destroy'])->name('crud.destroy');
        
        // URL: localhost:8020/crud/tmp-list
        // Route::get('/tmp-list', [CrudController::class, 'list']); 

    });

});
        
// Comentei pq agora to usando retorno na tela.        
// INERTIA e VUE Estudo;
// route::get('/vue', function(){
//    return Inertia::render('Estudo');
//});

/*
// Agrupando todas as rotas que começam com /vue
Route::prefix('vue')->group(function () {
    
    // Alvo: GET /vue
    Route::get('/', function () {
        return Inertia::render('Estudo', [
            'dados_retornados' => session('dados_retornados'), 
            'flash'            => session('flash')
        ]);
    });

    // Alvo: POST /vue/produto/salvar
    Route::post('/produto/salvar', [EstudoController::class, 'salvarProduto']);

    // Alvo: GET /vue/enviando
    Route::get('/enviando', [EstudoController::class, 'mostrarPagina']);
    
});

*/